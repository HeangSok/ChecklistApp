//
//  ChecklistApp.swift
//  Checklist
//
//  Created by Heang Sok on 14/4/2022.
//

import SwiftUI


@main
struct ChecklistApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
    
}

